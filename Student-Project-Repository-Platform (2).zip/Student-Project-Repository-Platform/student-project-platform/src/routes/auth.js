const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { authenticate } = require('../middleware/auth');
const router = express.Router();

const normalizeRole = role => {
  const value = String(role || '').trim().toLowerCase();
  if (value === 'teacher') return 'faculty';
  return ['student', 'faculty', 'admin'].includes(value) ? value : 'student';
};

const safeUser = u => ({ id: u.id, name: u.name, email: u.email, role: u.role, department: u.department || '' });
function tokenFor(user) {
  return jwt.sign({ id: user.id, name: user.name, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: '8h' });
}
router.post('/register', (req, res) => {
  const { name, email, password, role = 'student', department = '' } = req.body || {};
  if (!name?.trim() || !email?.trim() || !password) return res.status(400).json({ error: 'Name, email and password are required.' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must contain at least 8 characters.' });
  const normalizedRole = normalizeRole(role);

  try {
    const hash = bcrypt.hashSync(password, 10);
    const result = db.prepare('INSERT INTO users (name,email,password_hash,role,department) VALUES (?,?,?,?,?)')
      .run(name.trim(), email.trim().toLowerCase(), hash, normalizedRole, String(department).trim().slice(0,100));
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ token: tokenFor(user), user: safeUser(user) });
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) return res.status(409).json({ error: 'An account with this email already exists.' });
    res.status(500).json({ error: 'Could not create account.' });
  }
});
router.post('/login', (req, res) => {
  const { email, password, role } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Enter your email and password.' });
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email).trim().toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: 'Incorrect email or password.' });

  if (role !== undefined) {
    const expectedRole = normalizeRole(role);
    if (expectedRole === 'student' && user.role !== 'student') return res.status(403).json({ error: 'This account is not a student account.' });
    if (expectedRole === 'faculty' && user.role !== 'faculty') return res.status(403).json({ error: 'This account is not a teacher account.' });
  }

  res.json({ token: tokenFor(user), user: safeUser(user) });
});
router.get('/me', authenticate, (req, res) => {
  const user = db.prepare('SELECT id,name,email,role,department,created_at FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'Account not found.' });
  res.json({ user });
});
router.patch('/profile', authenticate, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'Account not found.' });

  const body = req.body || {};
  const name = body.name === undefined ? user.name : String(body.name).trim();
  const email = body.email === undefined ? user.email : String(body.email).trim().toLowerCase();
  const department = body.department === undefined ? user.department : String(body.department).trim();
  const changingPassword = body.new_password !== undefined && body.new_password !== '';

  if (!name || name.length > 100) return res.status(400).json({ error: 'Name is required and must be 100 characters or fewer.' });
  if (!email || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (department.length > 100) return res.status(400).json({ error: 'Department must be 100 characters or fewer.' });
  if (changingPassword && (typeof body.new_password !== 'string' || body.new_password.length < 8 || body.new_password.length > 128)) {
    return res.status(400).json({ error: 'New password must contain 8 to 128 characters.' });
  }
  if (changingPassword && (typeof body.current_password !== 'string' || !bcrypt.compareSync(body.current_password, user.password_hash))) {
    return res.status(400).json({ error: 'Your current password is incorrect.' });
  }

  try {
    if (changingPassword) {
      db.prepare('UPDATE users SET name=?,email=?,department=?,password_hash=? WHERE id=?')
        .run(name, email, department, bcrypt.hashSync(body.new_password, 10), user.id);
    } else {
      db.prepare('UPDATE users SET name=?,email=?,department=? WHERE id=?').run(name, email, department, user.id);
    }
    const updatedUser = db.prepare('SELECT id,name,email,role,department,created_at FROM users WHERE id=?').get(user.id);
    res.json({ user: updatedUser, token: tokenFor(updatedUser) });
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) return res.status(409).json({ error: 'An account with this email already exists.' });
    console.error('Could not update profile:', err);
    res.status(500).json({ error: 'Could not update profile.' });
  }
});
module.exports = router;
