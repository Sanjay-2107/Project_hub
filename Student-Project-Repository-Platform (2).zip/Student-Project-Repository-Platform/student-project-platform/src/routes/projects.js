const express = require('express');
const db = require('../db');
const { authenticate, allowRoles } = require('../middleware/auth');
const router = express.Router();
router.use(authenticate);

const projectSelect = `SELECT p.*, u.name AS owner_name, u.department AS owner_department,
 (SELECT COUNT(*) FROM submissions s WHERE s.project_id=p.id) AS submission_count,
 (SELECT ROUND(AVG((e.innovation+e.implementation+e.presentation+e.documentation)/4.0),1)
  FROM submissions s JOIN evaluations e ON e.submission_id=s.id WHERE s.project_id=p.id) AS average_score
 FROM projects p JOIN users u ON u.id=p.student_id`;
function canView(user, project) {
  if (user.role === 'admin' || user.role === 'faculty') return true;
  return project.student_id === user.id || project.visibility === 'public' && project.status === 'approved';
}
router.get('/', (req, res) => {
  const { search = '', domain = '', status = '' } = req.query;
  let rows = db.prepare(`${projectSelect} ORDER BY p.updated_at DESC`).all();
  rows = rows.filter(p => canView(req.user, p));
  if (search) { const q = String(search).toLowerCase(); rows = rows.filter(p => [p.title,p.abstract,p.tech_stack,p.owner_name].some(v => String(v || '').toLowerCase().includes(q))); }
  if (domain) rows = rows.filter(p => p.domain === domain);
  if (status && ['draft','submitted','under_review','revision_requested','approved'].includes(status)) rows = rows.filter(p => p.status === status);
  res.json({ projects: rows });
});
router.get('/teachers', allowRoles('student'), (_req, res) => {
  const teachers = db.prepare("SELECT id,name,department FROM users WHERE role='faculty' ORDER BY name").all();
  res.json({ teachers });
});
router.get('/:id', (req, res) => {
  const project = db.prepare(`${projectSelect} WHERE p.id = ?`).get(Number(req.params.id));
  if (!project) return res.status(404).json({ error: 'Project not found.' });
  if (!canView(req.user, project)) return res.status(403).json({ error: 'This project is private.' });
  const submissions = db.prepare(`SELECT s.*,u.name AS assigned_teacher_name,
    (SELECT ROUND(AVG((e.innovation+e.implementation+e.presentation+e.documentation)/4.0),1) FROM evaluations e WHERE e.submission_id=s.id) AS score
    FROM submissions s LEFT JOIN users u ON u.id=s.faculty_id WHERE s.project_id=? ORDER BY s.version DESC`).all(project.id);
  const assignments = db.prepare('SELECT ea.id,ea.faculty_id,u.name AS faculty_name,u.email AS faculty_email FROM evaluator_assignments ea JOIN users u ON u.id=ea.faculty_id WHERE ea.project_id=?').all(project.id);
  res.json({ project, submissions, assignments });
});
router.post('/', allowRoles('student'), (req, res) => {
  const { title, abstract, domain = 'Other', tech_stack = '', github_url = '', demo_url = '', team_members = '', visibility = 'private' } = req.body || {};
  if (!title?.trim() || !abstract?.trim()) return res.status(400).json({ error: 'Project title and abstract are required.' });
  if (!['private','public'].includes(visibility)) return res.status(400).json({ error: 'Invalid visibility.' });
  const result = db.prepare(`INSERT INTO projects (title,abstract,domain,tech_stack,github_url,demo_url,team_members,visibility,student_id) VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(title.trim().slice(0,150), abstract.trim().slice(0,5000), String(domain).slice(0,80), String(tech_stack).slice(0,300), safeUrl(github_url), safeUrl(demo_url), String(team_members).slice(0,1000), visibility, req.user.id);
  res.status(201).json({ project: db.prepare(`${projectSelect} WHERE p.id=?`).get(result.lastInsertRowid) });
});
router.patch('/:id', allowRoles('student','admin'), (req, res) => {
  const id = Number(req.params.id); const p = db.prepare('SELECT * FROM projects WHERE id=?').get(id);
  if (!p) return res.status(404).json({ error: 'Project not found.' });
  if (req.user.role !== 'admin' && p.student_id !== req.user.id) return res.status(403).json({ error: 'You can edit only your own projects.' });
  if (p.status === 'approved' && req.user.role !== 'admin') return res.status(400).json({ error: 'Approved projects cannot be edited. Contact an administrator.' });
  const fields = ['title','abstract','domain','tech_stack','github_url','demo_url','team_members','visibility'];
  const values = fields.map(k => req.body[k] === undefined ? p[k] : req.body[k]);
  if (!String(values[0]).trim() || !String(values[1]).trim()) return res.status(400).json({ error: 'Project title and abstract are required.' });
  if (!['private','public'].includes(values[7])) return res.status(400).json({ error: 'Invalid visibility.' });
  values[4] = safeUrl(values[4]); values[5] = safeUrl(values[5]);
  db.prepare(`UPDATE projects SET title=?,abstract=?,domain=?,tech_stack=?,github_url=?,demo_url=?,team_members=?,visibility=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(...values, id);
  res.json({ project: db.prepare(`${projectSelect} WHERE p.id=?`).get(id) });
});
router.post('/:id/submit', allowRoles('student'), (req, res) => {
  const id = Number(req.params.id); const p = db.prepare('SELECT * FROM projects WHERE id=?').get(id);
  if (!p) return res.status(404).json({ error: 'Project not found.' });
  if (p.student_id !== req.user.id) return res.status(403).json({ error: 'You can submit only your own projects.' });
  if (p.status === 'approved') return res.status(400).json({ error: 'This project is already approved.' });
  const facultyId = Number(req.body?.faculty_id);
  if (!Number.isInteger(facultyId) || facultyId < 1) return res.status(400).json({ error: 'Select a teacher for this submission.' });
  const teacher = db.prepare("SELECT id FROM users WHERE id=? AND role='faculty'").get(facultyId);
  if (!teacher) return res.status(400).json({ error: 'Select a valid teacher account.' });
  const report_url = safeUrl(req.body?.report_url || ''); const notes = String(req.body?.notes || '').slice(0,2000);
  const submit = db.transaction(() => {
    const version = db.prepare('SELECT COALESCE(MAX(version),0)+1 AS next FROM submissions WHERE project_id=?').get(id).next;
    const result = db.prepare('INSERT INTO submissions (project_id,faculty_id,version,report_url,notes) VALUES (?,?,?,?,?)').run(id,facultyId,version,report_url,notes);
    db.prepare("UPDATE projects SET status='submitted',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(id);
    return db.prepare('SELECT * FROM submissions WHERE id=?').get(result.lastInsertRowid);
  });
  const submission = submit();
  res.status(201).json({ submission, teacher: db.prepare('SELECT id,name,department FROM users WHERE id=?').get(facultyId) });
});
router.get('/:id/evaluations', (req, res) => {
  const p = db.prepare('SELECT * FROM projects WHERE id=?').get(Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'Project not found.' });
  if (req.user.role === 'student' && p.student_id !== req.user.id) return res.status(403).json({ error: 'Not allowed.' });
  const evaluations = db.prepare(`SELECT e.*,u.name AS evaluator_name,s.version FROM evaluations e JOIN users u ON u.id=e.evaluator_id JOIN submissions s ON s.id=e.submission_id WHERE s.project_id=? ORDER BY e.created_at DESC`).all(p.id);
  res.json({ evaluations });
});
function safeUrl(value) {
  const s = String(value || '').trim(); if (!s) return '';
  try { const u = new URL(s); return ['https:','http:'].includes(u.protocol) ? s.slice(0,500) : ''; } catch (_) { return ''; }
}
module.exports = router;
