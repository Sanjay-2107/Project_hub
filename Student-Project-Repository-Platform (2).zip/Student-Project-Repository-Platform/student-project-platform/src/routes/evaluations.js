const express = require('express');
const db = require('../db');
const { authenticate, allowRoles } = require('../middleware/auth');
const router = express.Router();
router.use(authenticate);

router.get('/assigned', allowRoles('faculty','admin'), (req, res) => {
  const params = [];
  let sql = `SELECT p.id AS project_id,p.title,p.domain,p.status,p.updated_at,u.name AS student_name,
    s.id AS submission_id,s.version,s.notes,s.report_url,s.submitted_at,
    COALESCE(s.faculty_id,ea.faculty_id) AS faculty_id
    FROM submissions s JOIN projects p ON p.id=s.project_id JOIN users u ON u.id=p.student_id
    LEFT JOIN evaluator_assignments ea ON ea.project_id=p.id AND s.faculty_id IS NULL
    WHERE 1=1`;
  if (req.user.role === 'faculty') { sql += ' AND (s.faculty_id=? OR ea.faculty_id=?)'; params.push(req.user.id,req.user.id); }
  sql += ' ORDER BY s.submitted_at DESC';
  res.json({ assignments: db.prepare(sql).all(...params) });
});
router.post('/:submissionId', allowRoles('faculty','admin'), (req, res) => {
  const sid = Number(req.params.submissionId);
  const sub = db.prepare('SELECT s.*,p.id AS project_id,p.student_id,p.status FROM submissions s JOIN projects p ON p.id=s.project_id WHERE s.id=?').get(sid);
  if (!sub) return res.status(404).json({ error: 'Submission not found.' });
  if (req.user.role === 'faculty') {
    if (sub.faculty_id && sub.faculty_id !== req.user.id) return res.status(403).json({ error: 'You are not assigned to evaluate this submission.' });
    const assignment = db.prepare('SELECT id FROM evaluator_assignments WHERE project_id=? AND faculty_id=?').get(sub.project_id,req.user.id);
    if (!sub.faculty_id && !assignment) return res.status(403).json({ error: 'You are not assigned to evaluate this project.' });
  }
  const { innovation, implementation, presentation, documentation, feedback = '', decision = 'revision_requested' } = req.body || {};
  const scores = [innovation,implementation,presentation,documentation].map(Number);
  if (scores.some(n => !Number.isInteger(n) || n < 1 || n > 10)) return res.status(400).json({ error: 'Each score must be a whole number from 1 to 10.' });
  if (!['approved','revision_requested','under_review'].includes(decision)) return res.status(400).json({ error: 'Invalid review decision.' });
  try {
    const old = db.prepare('SELECT id FROM evaluations WHERE submission_id=? AND evaluator_id=?').get(sid,req.user.id);
    if (old) db.prepare('UPDATE evaluations SET innovation=?,implementation=?,presentation=?,documentation=?,feedback=?,created_at=CURRENT_TIMESTAMP WHERE id=?').run(...scores,String(feedback).slice(0,3000),old.id);
    else db.prepare('INSERT INTO evaluations (submission_id,evaluator_id,innovation,implementation,presentation,documentation,feedback) VALUES (?,?,?,?,?,?,?)').run(sid,req.user.id,...scores,String(feedback).slice(0,3000));
    db.prepare('UPDATE projects SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(decision,sub.project_id);
    res.json({ message: 'Evaluation saved.', average: Number((scores.reduce((a,b)=>a+b,0)/4).toFixed(1)), status: decision });
  } catch (_) { res.status(500).json({ error: 'Could not save evaluation.' }); }
});
module.exports = router;
