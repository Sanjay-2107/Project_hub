const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { authenticate, allowRoles } = require('../middleware/auth');
const router = express.Router();
router.use(authenticate, allowRoles('admin'));
router.get('/overview', (req,res) => {
 const counts = {
  users: db.prepare('SELECT COUNT(*) n FROM users').get().n,
  students: db.prepare("SELECT COUNT(*) n FROM users WHERE role='student'").get().n,
  faculty: db.prepare("SELECT COUNT(*) n FROM users WHERE role='faculty'").get().n,
  projects: db.prepare('SELECT COUNT(*) n FROM projects').get().n,
  pending: db.prepare("SELECT COUNT(*) n FROM projects WHERE status IN ('submitted','under_review')").get().n,
  approved: db.prepare("SELECT COUNT(*) n FROM projects WHERE status='approved'").get().n
 };
 const statusBreakdown = db.prepare('SELECT status,COUNT(*) AS count FROM projects GROUP BY status').all();
 const recent = db.prepare(`SELECT p.id,p.title,p.status,p.created_at,u.name AS student_name FROM projects p JOIN users u ON u.id=p.student_id ORDER BY p.created_at DESC LIMIT 8`).all();
 res.json({ counts, statusBreakdown, recent });
});
router.get('/users', (req,res) => res.json({ users: db.prepare('SELECT id,name,email,role,department,created_at FROM users ORDER BY created_at DESC').all() }));
router.post('/faculty', (req,res) => {
 const { name,email,password,department='' } = req.body || {};
 if (!name?.trim() || !email?.trim() || !password || password.length<8) return res.status(400).json({error:'Name, email and a password of at least 8 characters are required.'});
 try {
  const r=db.prepare("INSERT INTO users(name,email,password_hash,role,department) VALUES(?,?,?,'faculty',?)").run(name.trim(),email.trim().toLowerCase(),bcrypt.hashSync(password,10),String(department).slice(0,100));
  res.status(201).json({user:db.prepare('SELECT id,name,email,role,department FROM users WHERE id=?').get(r.lastInsertRowid)});
 } catch(e) { if(String(e.message).includes('UNIQUE')) return res.status(409).json({error:'Email already exists.'}); res.status(500).json({error:'Could not create faculty account.'}); }
});
router.post('/assign', (req,res) => {
 const projectId=Number(req.body?.project_id), facultyId=Number(req.body?.faculty_id);
 const project=db.prepare('SELECT id FROM projects WHERE id=?').get(projectId);
 const faculty=db.prepare("SELECT id FROM users WHERE id=? AND role='faculty'").get(facultyId);
 if(!project||!faculty) return res.status(400).json({error:'Choose a valid project and faculty account.'});
 try { db.prepare('INSERT INTO evaluator_assignments(project_id,faculty_id) VALUES(?,?)').run(projectId,facultyId); }
 catch(e) { if(String(e.message).includes('UNIQUE')) return res.status(409).json({error:'This evaluator is already assigned.'}); throw e; }
 db.prepare("UPDATE projects SET status=CASE WHEN status='submitted' THEN 'under_review' ELSE status END,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(projectId);
 res.status(201).json({message:'Evaluator assigned successfully.'});
});
router.delete('/users/:id', (req,res) => {
 const id=Number(req.params.id); if(id===req.user.id) return res.status(400).json({error:'You cannot delete your own account.'});
 const target=db.prepare('SELECT id,role FROM users WHERE id=?').get(id); if(!target) return res.status(404).json({error:'User not found.'});
 db.prepare('DELETE FROM users WHERE id=?').run(id); res.json({message:'User deleted.'});
});
module.exports = router;
