const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'projects.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('student','faculty','admin')) DEFAULT 'student',
 department TEXT DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS projects (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 abstract TEXT NOT NULL,
 domain TEXT NOT NULL DEFAULT 'Other',
 tech_stack TEXT NOT NULL DEFAULT '',
 github_url TEXT DEFAULT '',
 demo_url TEXT DEFAULT '',
 visibility TEXT NOT NULL DEFAULT 'private' CHECK(visibility IN ('private','public')),
 status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','submitted','under_review','revision_requested','approved')),
 student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 team_members TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS submissions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
 faculty_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 version INTEGER NOT NULL,
 report_url TEXT DEFAULT '',
 notes TEXT DEFAULT '',
 submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(project_id, version)
);
CREATE TABLE IF NOT EXISTS evaluator_assignments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
 faculty_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 assigned_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(project_id, faculty_id)
);
CREATE TABLE IF NOT EXISTS evaluations (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 submission_id INTEGER NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
 evaluator_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 innovation INTEGER NOT NULL CHECK(innovation BETWEEN 1 AND 10),
 implementation INTEGER NOT NULL CHECK(implementation BETWEEN 1 AND 10),
 presentation INTEGER NOT NULL CHECK(presentation BETWEEN 1 AND 10),
 documentation INTEGER NOT NULL CHECK(documentation BETWEEN 1 AND 10),
 feedback TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(submission_id, evaluator_id)
);
CREATE INDEX IF NOT EXISTS idx_projects_student ON projects(student_id);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_submissions_project ON submissions(project_id);
`);

const submissionColumns = db.pragma('table_info(submissions)');
if (!submissionColumns.some(column => column.name === 'faculty_id')) {
  db.exec('ALTER TABLE submissions ADD COLUMN faculty_id INTEGER REFERENCES users(id) ON DELETE SET NULL');
}
db.exec('CREATE INDEX IF NOT EXISTS idx_submissions_faculty ON submissions(faculty_id)');

function ensureUser({ email, password, name, role, department }) {
  if (!email || !password) return;
  const normalizedEmail = String(email).trim().toLowerCase();
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(normalizedEmail);
  if (!existing) {
    const hash = bcrypt.hashSync(password, 10);
    db.prepare('INSERT INTO users (name,email,password_hash,role,department) VALUES (?,?,?,?,?)')
      .run(name, normalizedEmail, hash, role, department || '');
  }
}

const adminEmail = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const adminPassword = process.env.ADMIN_PASSWORD || '';
const adminName = (process.env.ADMIN_NAME || 'Platform Administrator').trim();

if (adminEmail && adminPassword) {
  ensureUser({
    email: adminEmail,
    password: adminPassword,
    name: adminName || 'Platform Administrator',
    role: 'admin',
    department: 'Administration',
  });
} else {
  console.warn('No admin credentials configured in .env. Add ADMIN_EMAIL and ADMIN_PASSWORD before running the app for production use.');
}

ensureUser({
  email: process.env.TEACHER_EMAIL,
  password: process.env.TEACHER_PASSWORD,
  name: process.env.TEACHER_NAME || 'Teacher User',
  role: 'faculty',
  department: 'Computer Science',
});

ensureUser({
  email: process.env.STUDENT_EMAIL,
  password: process.env.STUDENT_PASSWORD,
  name: process.env.STUDENT_NAME || 'Student User',
  role: 'student',
  department: 'Computer Science',
});

module.exports = db;
