@echo off
cd /d "%~dp0"
echo Installing project dependencies (first run only)...
if not exist node_modules call npm install
if errorlevel 1 (
  echo Dependency installation failed. Check your internet connection and Node.js installation.
  pause
  exit /b 1
)
if not exist .env copy .env.example .env
echo Starting ProjectHub at http://localhost:3000
npm start
pause
