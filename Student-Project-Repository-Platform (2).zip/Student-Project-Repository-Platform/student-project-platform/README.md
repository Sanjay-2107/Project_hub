# ProjectHub — Student Project Repository & Evaluation Platform

A beginner-friendly full-stack web application for students to manage academic projects, faculty to evaluate submissions, and administrators/coordinators to assign evaluators and manage accounts.

## Features

- Student registration and login with password hashing.
- Role-based access: student, faculty, administrator.
- Editable profiles and password changes verified using the current password.
- Create and edit project records, abstracts, team details, technology stack, GitHub links and demo links.
- Submit versioned deliverables with a report link and notes, and select the teacher who will evaluate that specific submission.
- Faculty assignments and a 4-part scoring rubric: innovation, implementation, presentation and documentation (each 1–10).
- Feedback and review decisions: approved, revision requested, or under review.
- Admin overview, faculty account creation, evaluator assignment, user management and project browsing.
- Approved public project repository, project search/filtering, responsive layout.
- SQLite database persisted to `data/projects.db`.
- Basic security measures: bcrypt password hashes, JWT expiration, role checks, request size limit, Helmet, login/register rate limiting and URL protocol validation.

## Requirements

- Node.js 20 LTS is required for this project on Windows. The native SQLite dependency used here does not build correctly under Node 24+ without Visual Studio C++ tooling.
- npm, included with Node.js.

## Run locally (Windows / macOS / Linux)

1. Extract the ZIP file.
2. Open a terminal in the extracted `student-project-platform` folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env`. On Windows PowerShell:

   ```powershell
   Copy-Item .env.example .env
   ```

   On macOS/Linux:

   ```bash
   cp .env.example .env
   ```

5. Open `.env` and replace `JWT_SECRET` with a long random secret. Set real admin credentials in `.env` before the first run so the system does not rely on demo defaults.
6. Start the server:

   ```bash
   npm start
   ```

7. Open **http://localhost:3000** in your browser.

The database is created automatically at `data/projects.db` the first time the server starts. Keep this file to retain data. Do not delete it unless you want to reset the database.

## First-run administrator account

Set a real admin email and password in `.env` before starting the application for the first time. The app will create the administrator account only when those values are present and the email is not already in the database.

Changing `ADMIN_PASSWORD` later does not automatically change an already-created account's password. If you need to reset the local installation, stop the server, back up or remove `data/projects.db`, set the environment values, then restart (removing the DB deletes all app data).

## Suggested demo flow

1. Sign in as admin and create a faculty account from the coordinator dashboard.
2. Sign out and register a student account.
3. Create a project and add its abstract, tech stack, and optional GitHub/demo URLs.
4. Open the project details and submit a version with notes, a report link, and the teacher who should evaluate it.
5. Sign in as that teacher, open the assigned submission, fill in the four scores, add feedback, and choose a review decision.
7. Sign in as the student to see the updated project status and feedback.
8. Set project visibility to public; once approved, it appears in the approved-project showcase.

## Project structure

```text
student-project-platform/
├── public/
│   ├── index.html       # Page shell
│   ├── styles.css       # Responsive UI
│   └── app.js           # Browser-side application
├── src/
│   ├── db.js            # SQLite schema and initial admin seed
│   ├── server.js        # Express app
│   ├── middleware/auth.js
│   └── routes/
│       ├── auth.js
│       ├── projects.js
│       ├── evaluations.js
│       └── admin.js
├── data/                # Created automatically; SQLite database
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

## Main API endpoints

- `POST /api/auth/register` — student registration
- `POST /api/auth/login` — sign in
- `GET /api/auth/me` — current user
- `GET /api/projects` — browse accessible projects; supports `search`, `domain`, `status` query parameters
- `POST /api/projects` — create project (student)
- `GET /api/projects/:id` — project details and submission history
- `PATCH /api/projects/:id` — update a project
- `POST /api/projects/:id/submit` — submit a new version
- `GET /api/projects/teachers` — list teacher accounts for the student submission form
- `GET /api/projects/:id/evaluations` — feedback for a project
- `GET /api/evaluations/assigned` — evaluator's assigned submissions
- `POST /api/evaluations/:submissionId` — score and review a submission
- `GET /api/admin/overview` — coordinator statistics
- `GET /api/admin/users` — user list
- `POST /api/admin/faculty` — create faculty account
- `POST /api/admin/assign` — assign evaluator to project
- `DELETE /api/admin/users/:id` — delete user account
- `GET /api/health` — server health check

Authenticated endpoints require `Authorization: Bearer <token>`.

## Important notes / limitations

- This is a functional academic project MVP, not a production-certified system.
- Deliverables are stored as links, not uploaded directly to the server. This keeps the starter simple and avoids accepting arbitrary files. You can add cloud file storage in a later version.
- Students can self-register; faculty accounts are created by admins. The app does not yet include email verification, password reset, institution SSO, or automatic team invitations.
- JWT is stored in browser local storage for simplicity in this educational starter. For a production deployment, consider secure HttpOnly cookies, CSRF protections, stronger monitoring, HTTPS, backups, and an explicit data-retention policy.
- For deployment, use a host that supports a persistent disk for SQLite. Some serverless hosts use ephemeral filesystems; if using those, move to a managed database such as PostgreSQL. Never commit `.env` or the live database file to GitHub.
- No plagiarism detector is included. Similarity warnings should never be treated as proof of plagiarism without a fair human review.

## Troubleshooting

- **`npm` is not recognized:** install Node.js 18+ from the official Node.js website and reopen the terminal.
- **Native SQLite package fails to install:** use Node.js 20 LTS and run `npm install` again. On Windows, ensure your Node installation is current.
- **Port 3000 is busy:** change `PORT` in `.env` and open the corresponding localhost URL.
- **Forgot the local demo admin password:** stop the server and reset the local database only if you can discard its data; set the intended admin password in `.env` before restarting.
- **Blank or stale page:** refresh the browser after restarting the server; check the terminal for server errors.

## License

For learning and academic demonstration. Adapt the source to your institution's requirements before real use.
